function init () {
    function getHeight(){
        return $(window).height();
    }
    function getWidth(){
        return $(window).width();
    }
    var me = this;
    var array = $('.dialog');
    for (var i=0; i<array.length; i++) {
        var win = array[i];
        $(win).dialog({
            autoOpen: false,
            width: getWidth()*0.8,
            height: getHeight()*0.8,
            modal: true,
            closeOnEscape: true,
            buttons: [
                {
                    text: "Ok",
                    click: function() {
                        $( this ).dialog( "close" );
                    }
                },
                {
                    text: "Cancel",
                    click: function() {
                        $( this ).dialog( "close" );
                    }
                }
            ]
        });
    }
    // Link to open the dialog
    $( ".dialog-link" ).click(function(e) {
        e.preventDefault();
        var song = event.target.getAttribute('song');
        song = '#'+song;
        $(song).dialog( "open" );
    });
    $( ".dialog-link, #icons li" ).hover(
        function() {
            $( this ).addClass( "ui-state-hover" );
        },
        function() {
            $( this ).removeClass( "ui-state-hover" );
        }
    );
    $('.mission').readmore({
        speed: 75,
        lessLink: '<button class="btn btn-secondary">Read less</a>',
        moreLink: '<button class="btn btn-secondary">Read more</a>'
    });
    if ($(window).width() > 700) {
        $('.style1').css('max-width',$(window).width()).css('max-height',$(window).height());
    }
}